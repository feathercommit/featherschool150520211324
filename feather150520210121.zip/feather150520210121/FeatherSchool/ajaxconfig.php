<?php
$con =mysqli_connect("localhost", "root", "", "featherschool") or die("Error in database connection".mysqli_error($mysqli));
 $host = "localhost";  
 $db_user = "root";  
 $db_pass = "";  
 $dbname = "featherschool";  
 
 $connect = new PDO("mysql:host=$host; dbname=$dbname", $db_user, $db_pass); 
?>