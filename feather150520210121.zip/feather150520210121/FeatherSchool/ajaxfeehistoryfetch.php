 <?php

include('ajaxconfig.php');


$query = "SELECT * FROM student  WHERE 1 ";

if (isset($_POST['medium'])) {   
    $medium  = $_POST['medium'];
    if($medium!="")
    {
	$query .="and  medium = '$medium' ";    
    }
}
if (isset($_POST['standard'])) {
    $standard  = $_POST['standard'];
    if($standard!="")
    {
	$query .="and  standard = '$standard' ";
    }
}
if (isset($_POST['section']) ) {
    $section  = $_POST['section'];
    if($section!="")
    {
        $query .="and  section = '$section' ";
    } 
	
}
$statement = $connect->prepare($query);

$statement->execute();

$number_filter_row = $statement->rowCount();

$statement = $connect->prepare($query);

$statement->execute();

$result = $statement->fetchAll();

$data = array();?>


                                        <div class="form-group">
                                        <label>Student Name<span class="text-danger">*</span></label>
										
                                     
										    <select  tabindex="5" name="studentall" id="studentall"  class="form-control" >
                                            <option value="">Select Student Name</option>
										  <?php  foreach ($result as $row) {
											        $studentid = $row['studentid'];
													$studentname = $row['studentname'];
													$admissionno = $row['admissionno'];?>											 
                                               <option  value="<?php echo $studentid;?>"><?php echo $studentname." (".$admissionno.")";?></option>
											<?php } ?>
										 </select>
											
                                        </div>
