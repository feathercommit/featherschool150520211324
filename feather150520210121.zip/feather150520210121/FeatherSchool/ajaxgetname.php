<?php

include('ajaxconfig.php');




if(isset($_GET['regnum']))		
{	
$regnum=$_GET['regnum'];
}
    $qry = "SELECT studentid, studentname FROM student WHERE rollnumber='".$regnum."' ";
    $res =$con->query($qry)or die("Error in Get All Records".$con->error);
    $row = mysqli_fetch_array($res);
    $studentid = $row["studentid"];
    $studentname = $row["studentname"];
    $result = array($studentid, $studentname);
    $myJSON = json_encode($result);
    echo $myJSON;
?>