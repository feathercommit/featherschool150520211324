<?php 
include('ajaxconfig.php');
$studentall=0;
$studentindiv=0;
$studentid =0;
if (isset($_POST['studentindiv']) && $_POST['studentindiv']>0 ) 
{
    $studentindiv = $_POST['studentindiv'];
}
 if (isset($_POST['studentall']) && $_POST['studentall']>0) 
{
    $studentindiv = $_POST['studentall'];
    $studentall = $_POST['studentall'];
}

      
    
$query = "SELECT * FROM student WHERE 1 ";
    if ($studentindiv>0)
    {
    $query .="and  studentid = $studentindiv ";
    }	
   else
   {
    $query .="and  studentid = 0 ";

   }    


if (isset($_POST['medium']) && $studentall>0) {
    if ($_POST['medium']>0)
    {
    $medium  = $_POST['medium'];
	$query .="and  medium = '$medium' ";
    }
}
if (isset($_POST['standard']) && $studentall>0) {
    if ($_POST['standard']>0)
    {
    $standard  = $_POST['standard'];
	$query .="and  standard = '$standard' ";
    }
}
if (isset($_POST['section']) && $studentall>0) {
    if ($_POST['section']>0)
    {
    $section  = $_POST['section'];
	$query .="and  section = '$section' ";
    }
}

$statement = $connect->prepare($query);

$statement->execute();

$number_filter_row = $statement->rowCount();

$statement = $connect->prepare($query);

$statement->execute();

$result = $statement->fetchAll();

$data = array();

foreach ($result as $row) {

$admissionnumber    = $row['admissionno'];
$rollnumber         = $row['rollnumber'];
$class              = $row['standard'];
$section            = $row['section'];
$studentname        = $row['studentname'];
$studentid          = $row['studentid'];
?> 
  <div class="col-md-6">
 <table class="table table-bordered">
                                            <thead>
                                                <tr>                                              
                                                <th scope="col"  colspan="2" class=" text-center font-weight-bold bg-azure">Student Details</th>
                                                
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>                                         
                                                <td><label   id="admissionnumber" name="admissionnumber"></label>Admission Number</td>
                                                <td > <label> <?php if(isset($admissionnumber)) echo $admissionnumber; ?></label></td>
                                                </tr>
                                                <tr>                                              
                                                <td><label   id="rollnumber" name="rollnumber">Roll Number</label></td>
                                                <td> <label> <?php if(isset($rollnumber)) echo $rollnumber; ?></label></td>
                                                </tr>
                                                <tr>
                                                <td><label   id="classandsection" name="classandsection">Class & Section</label></td>
                                                <td > <label> <?php if(isset($class)) echo $class; if(isset($section)) echo " ".$section;?>  </label></td>
                                                </tr>
                                                <tr>                                             
                                                <td><label   id="studentname" name="studentname">Student Name</label></td>
                                                <td > <label> <?php if(isset($studentname)) echo $studentname; ?></label></td>
                                                </tr>
                                            </tbody>
                                            </table>
                                        </div>
                                        <?php } ?>
                                        <div class="col-md-6">

                                        <table class="table table-bordered">
                                            <thead>
                                                <tr>                                              
                                                <th scope="col"  colspan="2" class=" text-center font-weight-bold bg-azure">Fee Details</th>
                                                
                                                </tr>
                                            </thead>
                                            <tbody>
                                            <?php
                                            $groupfeesamount1 = 0;
                                            $feesreceived1    = 0;
                                            $scholarship1     = 0;
                                            $balance1         = 0;
                                                $query3 = "SELECT * FROM feescollection where 1 and  studentid   =  ".$studentid."";

		//echo $query2;
	//	die;
		$result3 = mysqli_query($con,$query3);
         while($row3 = mysqli_fetch_array($result3)){
			 $feecollectid                                           = $row3['feecollectid'];
             if($feecollectid>0){
             $query4 = "SELECT * FROM groupfees where 1 and  feecollectid   =  ".$feecollectid."";

            
             $result4 = mysqli_query($con,$query4);
              while($row4 = mysqli_fetch_array($result4)){
                  $groupfeesamount1                                  += $row4['groupfeesamount'];
                  $feesreceived1                                     += $row4['feesreceived'];
                  $scholarship1                                      += $row4['scholarship'];
                  $balance1                                          += $row4['balance'];


              
              }
            }
        }
           ?>
                                                <tr>                                         
                                                <td><label   id="grosspayable" name="grosspayable">Gross Payable</td>
                                                <td > <label  value="" id="" name=""><?php if(isset($groupfeesamount1)) echo $groupfeesamount1; ?></label></td>
                                                </tr>
                                                <tr>                                              
                                                <td><label  id="amountpayed" name="amountpayed">Amount Payed</label></td>
                                                <td ><label value="" id="" name=""><?php if(isset($feesreceived1)) echo $feesreceived1; ?></label></td>
                                                </tr>
                                                <tr>
                                                <td><label  id="concession" name="concession">Concession</label></td>
                                                <td ><label  value="" id="" name=""><?php if(isset($scholarship1)) echo $scholarship1; ?></label></td>
                                                </tr>
                                                <tr>
                                                <td><label   id="notpayable" name="notpayable">Not Payable</label></td>
                                                <td ><label value="" id="" name=""><?php if(isset($balance1)) echo $balance1; ?></label></td>
                                                </tr>
                                                <?php ?>
                                            </tbody>
                                            </table>
                                        </div>
                                    
                                    </div>


                                
                                      
                                      <div class="col-md-12">
                                      <table class="table table-bordered">
                                            <thead>
                                                <tr>                                              
                                                <th scope="col"  colspan="4" class=" text-center font-weight-bold bg-azure ">Paid Details</th>
                                                
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>                                         
                                                <th class="bg-azure text-light text-center">
                                                <label id="receiptdate" name="receiptdate" value="<?php if(isset($receiptdate)) echo $receiptdate; ?>" class="  justify-content-center">Receipt Date</label></th>
                                                <th class="bg-azure text-light text-center">
                                                <label id="receiptnumber" name="receiptnumber" value="" class="  justify-content-center">Receipt number</label></th>
                                                <th class="bg-azure text-light text-center">
                                                <label id="totalamount" name="totalamount" value="" class="  justify-content-center">Total Amount</label></th>
                                              <!--  <th class="bg-azure text-light text-center">
                                                <label id="grosspayable" name="action" value="" class="  justify-content-center">Action</label></th>-->
                                                
                                                
                                                
                                                </tr>
                                                <?php
                                                $query2 = "SELECT * FROM feescollection where 1 and  studentid   =  ".$studentid."";

		//echo $query2;
	//	die;
		$result2 = mysqli_query($con,$query2);
         while($row2 = mysqli_fetch_array($result2)){
			 $feecollectid                                           = $row2['feecollectid'];
             $receiptdate                                            = $row2['receiptdate'];
             $receiptnumber                                          = $row2['receiptnumber'];
             $finalfeecollected                                      = $row2['finalfeecollected'];
           if($feecollectid>0){
           ?>
	

                                                <tr>                                              
                                                <td><label id="grosspayable" name=""><?php if(isset($receiptdate)) echo $receiptdate; ?></label></td>
                                                <td><label id="grosspayable" name=""><?php if(isset($receiptnumber)) echo $receiptnumber; ?></label></td> 
                                                <td><label id="grosspayable" name=""><?php if(isset($finalfeecollected)) echo $finalfeecollected; ?></label></td>
                                                
                                                </tr>
                                                <?php } 
                                                else 
                                                { ?>
                                                <tr>
                                                <td><label id="grosspayable" name=""></label></td>
                                                <td><label id="grosspayable" name=""></label></td>
                                                <td><label id="grosspayable" name=""></label></td>
                                               
                                                </tr>
                                                <?php } }?>
                                               
                                               
                                            </tbody>
                                            </table>
                                                                         
