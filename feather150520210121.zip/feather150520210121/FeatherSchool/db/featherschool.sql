-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 15, 2021 at 10:22 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `featherschool`
--

-- --------------------------------------------------------

--
-- Table structure for table `amenityfee`
--

CREATE TABLE `amenityfee` (
  `amenityfeeid` int(11) NOT NULL,
  `amenityfees` varchar(255) NOT NULL,
  `amenityamount` varchar(255) NOT NULL,
  `amenitycollection` varchar(255) NOT NULL,
  `amenityduedate` varchar(255) NOT NULL,
  `feesid` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `amenityfee`
--

INSERT INTO `amenityfee` (`amenityfeeid`, `amenityfees`, `amenityamount`, `amenitycollection`, `amenityduedate`, `feesid`, `status`) VALUES
(5, 'bookfees', '7757', 'quaterly', '2021-05-07', '3', '0'),
(6, 'others', '4368', 'halfyearly', '2021-05-14', '3', '0'),
(7, 'bookfees', '77', 'halfyearly', '2021-05-27', '4', '0'),
(8, 'others', '43', 'annually', '2021-05-26', '4', '0');

-- --------------------------------------------------------

--
-- Table structure for table `birthday_wish`
--

CREATE TABLE `birthday_wish` (
  `id` int(11) NOT NULL,
  `birthdaymessage` varchar(255) NOT NULL,
  `charcount` int(255) NOT NULL,
  `messagecount` int(255) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `birthday_wish`
--

INSERT INTO `birthday_wish` (`id`, `birthdaymessage`, `charcount`, `messagecount`, `status`) VALUES
(100, 'Hello guna wish you many more happy returns of the day!', 55, 1, 1),
(101, 'Hi reka Have a amazing birthday! wishes from feather school', 59, 1, 1),
(102, 'Hi reka Have a amazing birthday! wishes from feather school                                            ', 59, 1, 1),
(103, 'Hi reka Have a amazing birthday! wishes from feather school                                            ', 59, 1, 1),
(104, 'Hi reka Have a amazing birthday! wishes from feather school                                            ', 59, 1, 1),
(105, 'Hi reka Have a amazing birthday!', 32, 1, 1),
(106, 'Hi reka Have a amazing birthday!', 32, 1, 0),
(107, 'Hi reka Have a amazing birthday! wishes from feather school', 59, 1, 1),
(108, 'Hi Ratha Have a amazing birthday! wishes from feather school', 0, 1, 0),
(109, 'Hi reka1 Have a amazing birthday! wishes from feather school                                            ', 104, 2, 1),
(110, 'Hi reka Have a amazing birthday! wishes from feather school                                            ', 59, 1, 1),
(111, 'Hi Renuka Have a amazing birthday! wishes from feather school. welcome', 70, 1, 1),
(112, 'Hi Ravi Have a amazing birthday! wishes from feather school                                                                                        ', 147, 3, 1),
(113, 'Hi Ravi Have a amazing birthday! wishes from feather school                                                                                        ', 147, 3, 0),
(114, 'Hi Ravi Have a amazing birthday! wishes from feather school                                                                                        ', 147, 3, 1),
(115, 'test message this is because of updation bug 1                                                                                       ', 89, 2, 0),
(116, 'adadadadadadadadadadadadadadadada ok', 36, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `coursefee`
--

CREATE TABLE `coursefee` (
  `coursefeeid` int(11) NOT NULL,
  `coursefees` varchar(255) NOT NULL,
  `courseamount` varchar(255) NOT NULL,
  `coursecollectiontype` varchar(255) NOT NULL,
  `courseduedate` varchar(255) NOT NULL,
  `feesid` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `coursefee`
--

INSERT INTO `coursefee` (`coursefeeid`, `coursefees`, `courseamount`, `coursecollectiontype`, `courseduedate`, `feesid`, `status`) VALUES
(3, 'tutionfees', '22', 'quaterly', '2021-05-06', '2', '0'),
(4, 'tutionfees', '22', 'quaterly', '2021-05-06', '2', '0'),
(5, 'specialfees', '223', 'monthly', '2021-05-05', '3', '0'),
(6, 'others', '663', 'quaterly', '2021-05-07', '3', '0'),
(7, 'tutionfees', '12', 'monthly', '2021-05-05', '4', '0'),
(8, 'tutionfees', '44', 'quaterly', '2021-05-19', '4', '0');

-- --------------------------------------------------------

--
-- Table structure for table `extrafee`
--

CREATE TABLE `extrafee` (
  `extrafeeid` int(11) NOT NULL,
  `extrafees` varchar(255) NOT NULL,
  `extraamount` varchar(255) NOT NULL,
  `extracollection` varchar(255) NOT NULL,
  `extraduedate` varchar(255) NOT NULL,
  `feesid` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `extrafee`
--

INSERT INTO `extrafee` (`extrafeeid`, `extrafees`, `extraamount`, `extracollection`, `extraduedate`, `feesid`, `status`) VALUES
(5, 'music', '445', 'quaterly', '2021-05-07', '3', '0'),
(6, 'yoga', '336', 'halfyearly', '2021-05-08', '3', '0'),
(7, 'yoga', '44', 'monthly', '2021-05-27', '4', '0'),
(8, 'others', '33', 'monthly', '2021-05-25', '4', '0');

-- --------------------------------------------------------

--
-- Table structure for table `feescollection`
--

CREATE TABLE `feescollection` (
  `feecollectid` int(5) NOT NULL,
  `receiptnumber` varchar(10) NOT NULL,
  `registernumber` varchar(30) NOT NULL,
  `studentid` varchar(5) NOT NULL,
  `receiptdate` date NOT NULL,
  `academicyear` varchar(20) NOT NULL,
  `standard` varchar(10) NOT NULL,
  `otherchanges` varchar(100) NOT NULL,
  `otherfeesreceived` varchar(60) NOT NULL,
  `totalfeecollected` varchar(30) NOT NULL,
  `finalfeecollected` varchar(30) NOT NULL,
  `feecollected` varchar(30) NOT NULL,
  `balancefeecollect` varchar(30) NOT NULL,
  `status` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feescollection`
--

INSERT INTO `feescollection` (`feecollectid`, `receiptnumber`, `registernumber`, `studentid`, `receiptdate`, `academicyear`, `standard`, `otherchanges`, `otherfeesreceived`, `totalfeecollected`, `finalfeecollected`, `feecollected`, `balancefeecollect`, `status`) VALUES
(1, '001', '121', '1', '2021-05-13', '2019-2020', 'III', 'No', '7500', '12500', '11000', '7500', '3500', 0),
(2, '002', '122', '2', '2021-05-13', '2019-2020', 'III', 'No', '6000', '9000', '8000', '6000', '2500', 0),
(3, '003', '123', '3', '2021-05-13', '2019-2020', 'III', 'No', '7000', '8000', '8000', '7000', '1000', 0);

-- --------------------------------------------------------

--
-- Table structure for table `feesmaster`
--

CREATE TABLE `feesmaster` (
  `feesid` int(11) NOT NULL,
  `standardlist` varchar(255) NOT NULL,
  `medium` varchar(255) NOT NULL,
  `academicyear` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `createddate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feesmaster`
--

INSERT INTO `feesmaster` (`feesid`, `standardlist`, `medium`, `academicyear`, `status`, `createddate`) VALUES
(3, 'LKG', 'English', '2002-2003', 0, '2021-05-05 02:20:26'),
(4, 'LKG', 'Tamil', '2002-2003', 0, '2021-05-05 05:18:22');

-- --------------------------------------------------------

--
-- Table structure for table `generalsms`
--

CREATE TABLE `generalsms` (
  `id` int(4) NOT NULL,
  `name` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `generalmessage` varchar(255) NOT NULL,
  `status` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `generalsms`
--

INSERT INTO `generalsms` (`id`, `name`, `contact`, `email`, `subject`, `generalmessage`, `status`) VALUES
(1, 'prithiviraj', '987654321', 'prithivirajk2503@gmail.com', 'test', 'test message to pappu                                            ', 1),
(2, 'Godson', '0987654321', 'ramubro@gmail.com', 'test', 'test', 1),
(3, 'prithiviraj', '0987654321', 'maha@gmail.com', 'test', 'hello world', 1),
(4, 'newname', '0987654321', 'new@gmail.com', 'ABC', 'innactive  ---1                                                                                        ', 1),
(5, 'ramki', '0987654321', 'prithivirajk@gmail.c', 'sub', 'inactive msg                                                                                        ', 1),
(6, 'krish', '3826402434', 'prithivirajk2503@gmail.com', 'innactive', 'innactive', 1),
(7, 'fkf', 'fhk', 'prithivirajk2503@gmail.com', 'fghf', 'hkgh', 0),
(8, 'generalsms', '1234567890', 'sdok@gmail.com', 'test subject', 'test ok new', 0);

-- --------------------------------------------------------

--
-- Table structure for table `groupfees`
--

CREATE TABLE `groupfees` (
  `groupfeeid` int(5) NOT NULL,
  `groupfees` int(50) NOT NULL,
  `groupfeesamount` int(10) DEFAULT NULL,
  `feesreceived` int(10) DEFAULT NULL,
  `scholarship` int(15) DEFAULT NULL,
  `balance` int(10) DEFAULT NULL,
  `feecollectid` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `groupfees`
--

INSERT INTO `groupfees` (`groupfeeid`, `groupfees`, `groupfeesamount`, `feesreceived`, `scholarship`, `balance`, `feecollectid`) VALUES
(1, 0, 5000, 3500, 500, 1000, 1),
(2, 0, 6000, 4000, 1000, 1000, 2),
(3, 0, 3000, 2000, 0, 1000, 2),
(4, 0, 3000, 3000, 0, 0, 3),
(5, 0, 2000, 2000, 0, 0, 3),
(6, 0, 3000, 2000, 0, 1000, 3);

-- --------------------------------------------------------

--
-- Table structure for table `holiday`
--

CREATE TABLE `holiday` (
  `holidayid` int(11) NOT NULL,
  `holidaytype` varchar(255) NOT NULL,
  `holidaystartdate` varchar(255) NOT NULL,
  `holidayenddate` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `status` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `holiday`
--

INSERT INTO `holiday` (`holidayid`, `holidaytype`, `holidaystartdate`, `holidayenddate`, `description`, `status`) VALUES
(1, 'testok', '04/27/2021', '04/29/2021', '                                                                                        ok                                            ', 0),
(2, 'DFDSF', '04/27/2021', '04/29/2021', 'test ok new                                         ', 0),
(3, 'TEST', '04/28/2021', '04/30/2021', 'TEST DESC', 0),
(4, 'TESTNEW', '04/28/2021', '04/30/2021', '                                                                                        TEST DESC                                                                                        ', 1),
(5, 'TESTll', '04/28/2021', '04/30/2021', '                                                                                        testdesc', 0),
(6, 'fdgf', '04/22/2021', '04/20/2021', 'gfdgdfgfd           ', 0),
(7, 'testred123', '04/21/2021', '04/22/2021', '                                                                                        testtest                                                                                                                                                               ', 0),
(8, 'retr', '04/28/2021', '05/20/2021', '                                     retretre etertertert                                                   ', 0);

-- --------------------------------------------------------

--
-- Table structure for table `payfees`
--

CREATE TABLE `payfees` (
  `payfeeid` int(5) NOT NULL,
  `payrupees` int(10) DEFAULT NULL,
  `paynumberofrupees` int(10) DEFAULT NULL,
  `payamount` int(10) NOT NULL,
  `feecollectid` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payfees`
--

INSERT INTO `payfees` (`payfeeid`, `payrupees`, `paynumberofrupees`, `payamount`, `feecollectid`) VALUES
(1, 2000, 3, 6000, 1),
(2, 2000, 4, 8000, 2),
(3, 2000, 3, 6000, 3),
(4, 500, 2, 1000, 3);

-- --------------------------------------------------------

--
-- Table structure for table `paymentremindersms`
--

CREATE TABLE `paymentremindersms` (
  `id` int(4) NOT NULL,
  `admissionnumber` varchar(10) NOT NULL,
  `payamount` int(6) NOT NULL,
  `duedate` varchar(255) NOT NULL,
  `remindermessage` varchar(255) NOT NULL,
  `status` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `paymentremindersms`
--

INSERT INTO `paymentremindersms` (`id`, `admissionnumber`, `payamount`, `duedate`, `remindermessage`, `status`) VALUES
(1, '0001', 6000, '2021-05-07', 'Swimming fee                                                                                                                                    ', 0),
(2, '0002', 7000, '2021-05-30', 'Book fees', 1);

-- --------------------------------------------------------

--
-- Table structure for table `pendingfee`
--

CREATE TABLE `pendingfee` (
  `pendingfeeid` int(11) NOT NULL,
  `studentname` varchar(50) NOT NULL,
  `rollnumber` varchar(50) NOT NULL,
  `medium` varchar(10) NOT NULL,
  `standard` varchar(10) NOT NULL,
  `section` varchar(10) NOT NULL,
  `academicyear` varchar(20) NOT NULL,
  `totalfee` int(10) NOT NULL,
  `pendingfee` int(10) NOT NULL,
  `status` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pendingfee`
--

INSERT INTO `pendingfee` (`pendingfeeid`, `studentname`, `rollnumber`, `medium`, `standard`, `section`, `academicyear`, `totalfee`, `pendingfee`, `status`) VALUES
(1, 'krishna', 'adfg4523', 'English', 'LKG', '0', '2003', 100000, 652435, 1),
(2, 'ramakrishnan', 'dfgert45', 'Tamil', 'I', 'C', '2010-2011', 100000, 789900000, 1),
(3, 'English', 'Tamil', 'Tamil', 'XII', '0', '2002', 100, 30, 0),
(4, 'karthik', '3rer4332', 'English', 'X', '0', '2014', 342463462, 351351, 0),
(5, 'developer', '234235', 'Tamil', 'UKG', '0', '2006', 100000, 432624643, 0),
(6, 'raj', 'e1155053', 'English', 'I', 'D', '2015-2016', 4000, 1000, 1),
(7, 'hariharan', 'e1155063', 'Tamil', 'VI', '0', '2013', 100000, 789900000, 0),
(8, 'tamil', 'e1155054', 'Tamil', 'I', 'C', '2006-2007', 10, 1000, 0),
(9, 'test1', '1231', 'Tamil', 'XI', 'D', '2021-2022', 1231, 111, 1),
(10, 'ok', 'ok', 'Tamil', 'I', 'A', '2021-2022', 12, 212, 0);

-- --------------------------------------------------------

--
-- Table structure for table `school`
--

CREATE TABLE `school` (
  `id` int(11) NOT NULL,
  `schoolname` varchar(255) NOT NULL,
  `address1` varchar(255) NOT NULL,
  `address2` varchar(255) NOT NULL,
  `pincode` varchar(255) NOT NULL,
  `landmark` varchar(255) NOT NULL,
  `district` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `website` varchar(255) NOT NULL,
  `phonenumber` varchar(255) NOT NULL,
  `landlinecode` varchar(255) NOT NULL,
  `landlinenumber` varchar(255) NOT NULL,
  `status` int(11) NOT NULL COMMENT 'active = 0 , inactive =1',
  `createddate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `school`
--

INSERT INTO `school` (`id`, `schoolname`, `address1`, `address2`, `pincode`, `landmark`, `district`, `state`, `email`, `website`, `phonenumber`, `landlinecode`, `landlinenumber`, `status`, `createddate`) VALUES
(1, 'featherschool', 'address first', 'address second', '12341234', 'marutham', 'vandavasi', 'tamilnadu', 'featherschool@gmail.com', 'www.feather.in', '1234567890', '04182', '274739', 0, '2021-04-17 10:04:39'),
(120, 'school1237', 'address1', 'address2', '12341', 'land1', 'district1', 'state1', 'support1@feathertechnology.in', 'website1', '123451', '044', '123451', 1, '2021-04-19 06:45:26'),
(121, 'schoolnew1', 'safsa', 'af', '142142', 'asaf', 'fasf', 'safsa', 'asfsaf@gmail.com', 'sfsaf.in', '3412421421', '04144', '414214', 1, '2021-04-19 12:57:34'),
(122, 'test', 'address1', 'address2', '34324', 'dsfdsf', 'dsf', 'tamilnadu', 'support@feathertechnology.in', 'asdsa', '2345325325', '044', '345435345', 1, '2021-04-19 13:00:43'),
(123, 'dfdf', 'sdfd', 'dsfds', '5342542', 'sdfdsf', 'fsddsf', 'dsfdsf', 'md@asmotors.in', 'dsfdsf', '34324324', '04144', '32432432', 0, '2021-04-19 11:46:03'),
(124, 'xcvcxv', 'cxvcxv', 'cxvcx', '254235325', 'cv', 'cxvcvc', 'dsfsdfdsf', 'md@asmotors.in', 'dsfdsfdsf', '45325325', '04182', '25325325', 0, '2021-04-19 11:48:42');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `staffid` int(11) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `middlename` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `employeenumber` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `bloodgroup` varchar(255) NOT NULL,
  `staffroll` varchar(255) NOT NULL,
  `qualification` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `pan` varchar(255) NOT NULL,
  `pfnumber` varchar(255) NOT NULL,
  `contactnumber` varchar(255) NOT NULL,
  `dateofjoining` varchar(255) NOT NULL,
  `appointmentletter` varchar(255) NOT NULL,
  `aadhaarnumber` varchar(255) NOT NULL,
  `emergencycontactperson` varchar(255) NOT NULL,
  `emergencycontactnumber` varchar(255) NOT NULL,
  `transportation` varchar(255) NOT NULL,
  `flatno` varchar(255) NOT NULL,
  `area` varchar(255) NOT NULL,
  `district` varchar(255) NOT NULL,
  `pincode` varchar(255) NOT NULL,
  `bankname` varchar(255) NOT NULL,
  `accountnumber` varchar(255) NOT NULL,
  `branch` varchar(255) NOT NULL,
  `ifsccode` varchar(255) NOT NULL,
  `staffpath` varchar(255) NOT NULL,
  `basicpay` varchar(255) NOT NULL,
  `detection` varchar(255) NOT NULL,
  `detectionamount` varchar(255) NOT NULL,
  `hra` varchar(255) NOT NULL,
  `grosspay` varchar(255) NOT NULL,
  `netamount` varchar(255) NOT NULL,
  `transportallowance` varchar(255) NOT NULL,
  `medicalallowance` varchar(255) NOT NULL,
  `specialpay` varchar(255) NOT NULL,
  `title1` varchar(255) NOT NULL,
  `name1` varchar(255) NOT NULL,
  `issuedby1` varchar(255) NOT NULL,
  `title2` varchar(255) NOT NULL,
  `name2` varchar(255) NOT NULL,
  `issuedby2` varchar(255) NOT NULL,
  `title3` varchar(255) NOT NULL,
  `name3` varchar(255) NOT NULL,
  `issuedby3` varchar(255) NOT NULL,
  `documentpath` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `createddate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`staffid`, `firstname`, `middlename`, `lastname`, `employeenumber`, `gender`, `bloodgroup`, `staffroll`, `qualification`, `email`, `pan`, `pfnumber`, `contactnumber`, `dateofjoining`, `appointmentletter`, `aadhaarnumber`, `emergencycontactperson`, `emergencycontactnumber`, `transportation`, `flatno`, `area`, `district`, `pincode`, `bankname`, `accountnumber`, `branch`, `ifsccode`, `staffpath`, `basicpay`, `detection`, `detectionamount`, `hra`, `grosspay`, `netamount`, `transportallowance`, `medicalallowance`, `specialpay`, `title1`, `name1`, `issuedby1`, `title2`, `name2`, `issuedby2`, `title3`, `name3`, `issuedby3`, `documentpath`, `status`, `createddate`) VALUES
(2, 'test', 'waew', 'arweewr', '213213', 'Male', 'oi', 'PRINCIPAL', 'wqrwqr', 'asfsaf@gmail.com', '1234124', '1424', '12424', '04/22/2021', 'ffdfdf', '32342423', 'dsfds', '324325', 'transport', '325', '325432', 'sdfdsf', '2354325', 'dsfdsf', '3254353', 'fcfdsf', '325325', 'Screenshot_2.png', '352', '325', '325', '235', '325', '325', '325', '324', '324', 'dsfds', '343', 'drawr', 'sdf', 'dsf', 'dsfd', 'dsf', 'sdf', 'sdf', 'Screenshot_14.png', 0, '2021-04-28 00:40:24'),
(14, 'wttew', 'etewt', 'ewtewt', 'ewtewt', 'Male', 'ewrew', 'TGT', 'ewrew', 'dsfds@gmail.COM', '324324', '124', '432143214', '04/28/2021', 'fewr', '343243', 'tgfgfg', '2532', 'fgsf', '324324', 'fdgf', '342we45re', '5325', 'dffdgf', '245325', 'ffgdf', '434', 'Screenshot_3.png', '2421', '42', '24', '24', '24', '24', '24', '2424', '2424', 'fgsd', 'fgdsg', 'ddgds', 'sg', 'sdgdsgds', 'sgds', 'dsg', 'ssdgdsg', 'dsgdsgd', '', 0, '2021-04-29 02:18:05'),
(15, 'wttew', 'etewt', 'ewtewt', 'ewtewt', 'Male', 'ewrew', 'TGT', 'ewrew', 'dsfds@gmail.COM', '324324', '124', '432143214', '04/28/2021', 'fewr', '343243', 'tgfgfg', '2532', 'fgsf', '324324', 'fdgf', '342we45re', '5325', 'dffdgf', '245325', 'ffgdf', '434', 'Screenshot_3.png', '2421', '42', '24', '24', '24', '24', '24', '2424', '2424', 'fgsd', 'fgdsg', 'ddgds', 'sg', 'sdgdsgds', 'sgds', 'dsg', 'ssdgdsg', 'dsgdsgd', 'Screenshot_5.png', 0, '2021-04-29 02:23:02'),
(16, 'okok', 'etewt', 'ewtewt', 'ewtewt', 'Male', 'ewrew', 'TGT', 'ewrew', 'dsfds@gmail.COM', '324324', '124', '432143214', '04/29/2021', 'fewr', '343243', 'tgfgfg', '2532', 'fgsf', '324324', 'fdgf', '342we45re', '5325', 'dffdgf', '245325', 'ffgdf', '434', 'Screenshot_3.png', '2421', '42', '24', '24', '24', '24', '24', '2424', '2424', 'tst', 'fgdsg', 'ddgds', 'sg', 'sdgdsgds', 'sgds', 'dsg', 'ssdgdsg', 'dsgdsgd', 'Screenshot_5.png', 0, '2021-04-29 02:24:14');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `studentid` int(11) NOT NULL,
  `admissionno` varchar(255) NOT NULL,
  `studentname` varchar(255) NOT NULL,
  `surname` varchar(255) NOT NULL,
  `dateofbirth` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `mothertongue` varchar(255) NOT NULL,
  `aadhaarcard` varchar(255) NOT NULL,
  `bloodgroup` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `caste` varchar(255) NOT NULL,
  `subcaste` varchar(255) NOT NULL,
  `nationality` varchar(255) NOT NULL,
  `religion` varchar(255) NOT NULL,
  `pflatnoname` varchar(255) NOT NULL,
  `pstreet` varchar(255) NOT NULL,
  `parealocality` varchar(255) NOT NULL,
  `pdistrict` varchar(255) NOT NULL,
  `ppincode` varchar(255) NOT NULL,
  `pcheck` varchar(255) NOT NULL,
  `tflatnoname` varchar(255) NOT NULL,
  `tstreet` varchar(255) NOT NULL,
  `tarealocality` varchar(255) NOT NULL,
  `tdistrict` varchar(255) NOT NULL,
  `tpincode` varchar(255) NOT NULL,
  `standard` varchar(255) NOT NULL,
  `medium` varchar(255) NOT NULL,
  `section` varchar(255) NOT NULL,
  `rollnumber` varchar(255) NOT NULL,
  `concessiontype` varchar(255) NOT NULL,
  `concessionpercentage` varchar(255) NOT NULL,
  `facility` varchar(255) NOT NULL,
  `areaofstudent` varchar(255) NOT NULL,
  `fathername` varchar(255) NOT NULL,
  `fatheraadhaarnumber` varchar(255) NOT NULL,
  `fatheroccupation` varchar(255) NOT NULL,
  `natureofjob` varchar(255) NOT NULL,
  `telephone` varchar(255) NOT NULL,
  `fathermobile` varchar(255) NOT NULL,
  `fatheremailid` varchar(255) NOT NULL,
  `mothername` varchar(255) NOT NULL,
  `motheraadhaarnumber` varchar(255) NOT NULL,
  `monthlyincome` varchar(255) NOT NULL,
  `positionheld` varchar(255) NOT NULL,
  `liveswithguardian` varchar(255) NOT NULL,
  `mothermobile` varchar(255) NOT NULL,
  `smssentno` varchar(255) NOT NULL,
  `siblingname` varchar(255) NOT NULL,
  `siblingrefno` varchar(255) NOT NULL,
  `siblingschoolname` varchar(255) NOT NULL,
  `siblingstd` varchar(255) NOT NULL,
  `extracurricular` longtext NOT NULL,
  `studentphoto` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `Createddate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`studentid`, `admissionno`, `studentname`, `surname`, `dateofbirth`, `gender`, `mothertongue`, `aadhaarcard`, `bloodgroup`, `category`, `caste`, `subcaste`, `nationality`, `religion`, `pflatnoname`, `pstreet`, `parealocality`, `pdistrict`, `ppincode`, `pcheck`, `tflatnoname`, `tstreet`, `tarealocality`, `tdistrict`, `tpincode`, `standard`, `medium`, `section`, `rollnumber`, `concessiontype`, `concessionpercentage`, `facility`, `areaofstudent`, `fathername`, `fatheraadhaarnumber`, `fatheroccupation`, `natureofjob`, `telephone`, `fathermobile`, `fatheremailid`, `mothername`, `motheraadhaarnumber`, `monthlyincome`, `positionheld`, `liveswithguardian`, `mothermobile`, `smssentno`, `siblingname`, `siblingrefno`, `siblingschoolname`, `siblingstd`, `extracurricular`, `studentphoto`, `status`, `Createddate`) VALUES
(1, 'siva123', 'siva', 'surname', '05/12/2021', 'Male', 'Tamil', '12345', 'A+', 'BC', 'Brahmin - Gurukkal', 'okok', 'Indian', 'Muslim', 'wrewr', 'rewr', 'rewr', 'Nagapattinam', '12321321', '0', 'sfdsf', 'fsdsf', 'dsfdsf', 'Namakkal', '324324', 'LKG', 'Tamil', 'A', '121', 'Scholarship', '13', 'Hosteller', 'area', 'father', 'fgfdsgs', 'Business', 'ewtewt', '5345435', 'dfdsf', 'sfsfsf@gmail.com', 'mother', '353425', 'f24532', 'dsfds', '0', '32432325', '345345', 'fsafsa', '35252', 'ewtwt', 'UKG', 'okact', 'Screenshot_21.png', 1, '2021-05-03 23:24:13'),
(2, 'sathish443', 'sathish', 'surname', '05/05/2021', 'Male', 'Tamil', 'weww', 'B+', 'ST', 'Brahmin - Gurukkal', 'ewew', 'Indian', 'Hindu', '12', 'sads', 'sad', 'Nilgiris', '23424', 'Yes', '21', 'sadsa', 'sad', 'Perambalur', '342242', 'LKG', 'Tamil', 'B', '122', 'RTE', '', 'Hosteller', 'sadsadsa', 'sdsad', 'fd3424', 'Job', 'asdsa', '2424', '2332323', 'sfsfsf@gmail.com', 'sdsa', 'sadsad', '2424', 'asdd', 'Yes', '32432325', '34224', '242', '242', '2424', 'UKG', '                                                      sasdsadsad                                  ', 'Screenshot_21.png', 0, '2021-05-03 23:31:02'),
(3, 'karthi667', 'karthi', 'surname', '05/31/2021', 'Male', 'Tamil', '123456789012', 'A+', 'BC', 'Brahmin - Khedaval', 'sub', 'Indian', 'Hindu', '12', 'street', 'area', 'Madurai', '123123', '1', '12', 'street', 'area', 'Madurai', '123123', 'VII', 'Tamil', 'C', '123', 'General', '12', 'Hosteller', 'areanew', 'father', '121212121212', 'Business', 'joi', '1234', '1234123412', 'father@gmail.com', 'mother', '121212121211', '24242', 'ostion', '0', '2233441122', '121212334455', '11', '123', 'school', 'III', 'testok                           ', 'favicon.png', 0, '2021-05-04 05:43:50');

-- --------------------------------------------------------

--
-- Table structure for table `studentreport`
--

CREATE TABLE `studentreport` (
  `id` int(11) NOT NULL,
  `studentname` varchar(100) NOT NULL,
  `rollnumber` varchar(50) NOT NULL,
  `standard` varchar(10) NOT NULL,
  `section` varchar(10) NOT NULL,
  `reportfrom` varchar(100) NOT NULL,
  `reportto` varchar(100) NOT NULL,
  `workingdays` varchar(100) NOT NULL,
  `absent` varchar(100) NOT NULL,
  `attendancepercent` varchar(50) NOT NULL,
  `perattendance` varchar(50) NOT NULL,
  `perpunctuality` varchar(50) NOT NULL,
  `perdiscipline` varchar(50) NOT NULL,
  `perattitude` varchar(100) NOT NULL,
  `percommunication` varchar(100) NOT NULL,
  `perclassparticipation` varchar(100) NOT NULL,
  `percapability` varchar(100) NOT NULL,
  `perskill` varchar(100) NOT NULL,
  `test1name` varchar(100) NOT NULL,
  `test1marks` int(10) NOT NULL,
  `test2name` varchar(100) NOT NULL,
  `test2marks` int(10) NOT NULL,
  `test3name` varchar(100) NOT NULL,
  `test3marks` int(10) NOT NULL,
  `test4name` varchar(100) NOT NULL,
  `test4marks` int(10) NOT NULL,
  `reportcomments` varchar(255) NOT NULL,
  `status` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `studentreport`
--

INSERT INTO `studentreport` (`id`, `studentname`, `rollnumber`, `standard`, `section`, `reportfrom`, `reportto`, `workingdays`, `absent`, `attendancepercent`, `perattendance`, `perpunctuality`, `perdiscipline`, `perattitude`, `percommunication`, `perclassparticipation`, `percapability`, `perskill`, `test1name`, `test1marks`, `test2name`, `test2marks`, `test3name`, `test3marks`, `test4name`, `test4marks`, `reportcomments`, `status`) VALUES
(7, 'ramakrishnannnnnnnnnnnnnn', 'dfgert4543efer56757', 'I', 'B', '2021-05-21', '2021-05-15', '325236567565', '2346666666666666666666666', '235565656565656565656565656564', 'Excellent', 'Needs Improvement', 'Needs Improvement', 'Needs Improvement', 'Needs Improvement', 'Needs Improvement', 'Needs Improvement', 'Needs Improvement', 'commerce', 0, 'english', 234, 'maths', 234, 'science', 324, '2341343werygvfgsdfsyyyy', 0),
(9, 'krishnan', 'adfg4523', 'LKG', 'A', '2021-05-29', '2021-05-15', '34546', '34645', '36534', 'Good', 'Excellent', 'Excellent', 'Very Good', 'Very Good', 'Very Good', 'Very Good', 'Excellent', 'tye', 2147483647, 'fgjhjhg', 677, 'yjfyj', 67456, 'hjgj', 46745, '75647654', 1),
(10, 'karthik', '1234', 'XI', 'A', '2021-05-07', '2021-05-08', '1', '2', '3', 'Excellent', 'Excellent', 'Very Good', 'Excellent', 'Very Good', 'Good', 'Needs Improvement', 'Unsatisfactory', 'tamils', 12, 'englishs', 22, 'mathss', 12, 'sciences', 33, 'performance', 0),
(11, 'anonymous', '019237', 'LKG', 'F', '2021-05-20', '2021-05-07', '342', '4', '4252', 'Very Good', 'Excellent', 'Excellent', 'Very Good', 'Excellent', 'Good', 'Very Good', 'Very Good', 'tamil', 4364, 'english', 53234, 'maths', 234542, 'science', 34234, '242352345', 1),
(12, 'student 1', '123123', 'LKG', 'B', '2021-05-13', '2021-05-14', '123', '12', '11', 'Excellent', 'Very Good', 'Excellent', 'Excellent', 'Very Good', 'Very Good', 'Excellent', 'Very Good', '11', 12, '13', 14, '15', 16, '17', 181, 'comment1', 1),
(13, 'student 23', '123456', 'LKG', 'A', '2021-05-07', '2021-05-16', '11', '11', '11', 'Very Good', 'Very Good', 'Very Good', 'Needs Improvement', 'Excellent', 'Needs Improvement', 'Unsatisfactory', 'Excellent', '11', 12, '13', 14, '15', 16, '17', 18, 'test new3', 0);

-- --------------------------------------------------------

--
-- Table structure for table `studentrollback`
--

CREATE TABLE `studentrollback` (
  `studentrollbackid` int(5) NOT NULL,
  `standard` varchar(20) DEFAULT NULL,
  `section` varchar(20) DEFAULT NULL,
  `status` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `studentrollback`
--

INSERT INTO `studentrollback` (`studentrollbackid`, `standard`, `section`, `status`) VALUES
(1, 'LKG', 'A', 0),
(2, 'UKG', 'B', 0),
(3, 'III', 'D', 0);

-- --------------------------------------------------------

--
-- Table structure for table `studentrollbackreference`
--

CREATE TABLE `studentrollbackreference` (
  `referenceid` int(5) NOT NULL,
  `studentname` varchar(50) DEFAULT NULL,
  `rollnumber` varchar(20) DEFAULT NULL,
  `result` varchar(10) DEFAULT NULL,
  `checks` varchar(5) DEFAULT NULL,
  `status` varchar(5) DEFAULT NULL,
  `studentrollbackid` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `studentrollbackreference`
--

INSERT INTO `studentrollbackreference` (`referenceid`, `studentname`, `rollnumber`, `result`, `checks`, `status`, `studentrollbackid`) VALUES
(1, 'Prithivi', '1001', 'fail', '0', '0', 1),
(2, 'bakya', '1002', 'fail', '0', '0', 2),
(3, 'chessi', '1003', 'pass', '0', '0', 3);

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `subjectid` int(11) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `subjectcode` varchar(255) NOT NULL,
  `subjecttype` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `createddate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`subjectid`, `subject`, `subjectcode`, `subjecttype`, `status`, `createddate`) VALUES
(2, 'English', 'ENG123', 'Theory', 0, '2021-04-24 18:24:14'),
(3, 'Hindi', 'HIN123', 'Theory', 0, '2021-04-24 18:24:14'),
(4, 'Tamil', 'Tamil123', 'Theory', 0, '2021-04-24 18:24:14'),
(5, 'maths', '1234', 'Practical', 0, '2021-04-28 01:36:17');

-- --------------------------------------------------------

--
-- Table structure for table `subjectgroup`
--

CREATE TABLE `subjectgroup` (
  `subjectgroupid` int(11) NOT NULL,
  `standard` varchar(255) NOT NULL,
  `groupname` varchar(255) NOT NULL,
  `section` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `createddate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subjectgroup`
--

INSERT INTO `subjectgroup` (`subjectgroupid`, `standard`, `groupname`, `section`, `subject`, `status`, `createddate`) VALUES
(3, 'VI', 'test new', 'A,B,C,D', 'Hindi,Tamil', 0, '2021-04-24 18:23:52'),
(4, 'I', 'rewr', 'A', 'English,Hindi', 0, '2021-04-24 18:23:52'),
(5, 'IV', 'fourth', 'A,B,C,D', 'English', 0, '2021-04-24 18:23:52'),
(6, 'X', 'testok1', 'A,B', 'Hindi,Tamil', 1, '2021-04-28 01:40:59');

-- --------------------------------------------------------

--
-- Table structure for table `trust`
--

CREATE TABLE `trust` (
  `trustid` int(11) NOT NULL,
  `trustname` varchar(255) NOT NULL,
  `pannumber` varchar(255) NOT NULL,
  `tannumber` varchar(255) NOT NULL,
  `flatno` varchar(255) NOT NULL,
  `street` varchar(255) NOT NULL,
  `area` varchar(255) NOT NULL,
  `district` varchar(255) NOT NULL,
  `pincode` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `createddate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `trust`
--

INSERT INTO `trust` (`trustid`, `trustname`, `pannumber`, `tannumber`, `flatno`, `street`, `area`, `district`, `pincode`, `status`, `createddate`) VALUES
(1, 'trust', '12345', '67890', '223344', '85street', 'area', 'district', '123123', 0, '2021-04-17 18:30:15'),
(4, 'testtrust', '12345', '13414`14', '14124', 'rsarwarqstreet', 'wqrwqrarea', 'sfdfdistrict', '123123', 1, '2021-04-19 18:46:16'),
(5, 'trust1', '12341234', 'qrwqr123', '32', 'asfsaf', 'fssaf', 'asfsa', '23232', 0, '2021-04-24 23:57:09');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `user_tel` varchar(255) NOT NULL,
  `user_mail` varchar(255) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `Createddate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `user_name`, `user_tel`, `user_mail`, `user_password`, `status`, `Createddate`) VALUES
(1, 'support@feathertechnology.in', '', '', '5af15c0968669087d686da5cfd64f62b', '0', '2021-04-17 17:08:00');

-- --------------------------------------------------------

--
-- Table structure for table `user_logs`
--

CREATE TABLE `user_logs` (
  `loginid` int(11) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `login_date` varchar(255) NOT NULL,
  `fk_user_id` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_logs`
--

INSERT INTO `user_logs` (`loginid`, `ipaddress`, `login_date`, `fk_user_id`) VALUES
(1, '::1', '2021-04-17 05:14:16', '1'),
(2, '::1', '2021-04-17 05:16:15', '1'),
(3, '::1', '2021-04-17 05:17:36', '1'),
(4, '::1', '2021-04-19 09:50:40', '1'),
(5, '::1', '2021-04-23 10:45:10', '1'),
(6, '::1', '2021-04-24 06:52:22', '1'),
(7, '::1', '2021-04-24 10:36:30', '1'),
(8, '::1', '2021-04-24 10:37:55', '1'),
(9, '::1', '2021-04-24 10:39:46', '1'),
(10, '::1', '2021-04-24 11:56:41', '1'),
(11, '::1', '2021-04-25 12:28:33', '1'),
(12, '::1', '2021-04-26 10:23:53', '1'),
(13, '::1', '2021-04-26 10:42:25', '1'),
(14, '::1', '2021-04-27 01:32:36', '1'),
(15, '::1', '2021-04-27 08:12:46', '1'),
(16, '::1', '2021-04-29 10:34:22', '1'),
(17, '::1', '2021-04-29 11:20:33', '1'),
(18, '::1', '2021-04-30 10:33:16', '1'),
(19, '::1', '2021-04-30 10:34:57', '1'),
(20, '::1', '2021-05-01 12:21:25', '1'),
(21, '::1', '2021-05-01 04:54:12', '1'),
(22, '::1', '2021-05-04 10:27:10', '1'),
(23, '::1', '2021-05-05 07:25:33', '1'),
(24, '::1', '2021-05-06 12:03:20', '1'),
(25, '::1', '2021-05-06 11:00:45', '1'),
(26, '::1', '2021-05-07 04:28:21', '1'),
(27, '::1', '2021-05-07 05:24:13', '1'),
(28, '::1', '2021-05-07 11:56:56', '1'),
(29, '::1', '2021-05-09 03:58:57', '1'),
(30, '::1', '2021-05-13 04:22:59', '1'),
(31, '::1', '2021-05-13 11:57:33', '1'),
(32, '::1', '2021-05-14 04:29:22', '1'),
(33, '::1', '2021-05-14 08:09:56', '1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `amenityfee`
--
ALTER TABLE `amenityfee`
  ADD PRIMARY KEY (`amenityfeeid`);

--
-- Indexes for table `birthday_wish`
--
ALTER TABLE `birthday_wish`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `coursefee`
--
ALTER TABLE `coursefee`
  ADD PRIMARY KEY (`coursefeeid`);

--
-- Indexes for table `extrafee`
--
ALTER TABLE `extrafee`
  ADD PRIMARY KEY (`extrafeeid`);

--
-- Indexes for table `feescollection`
--
ALTER TABLE `feescollection`
  ADD PRIMARY KEY (`feecollectid`);

--
-- Indexes for table `feesmaster`
--
ALTER TABLE `feesmaster`
  ADD PRIMARY KEY (`feesid`);

--
-- Indexes for table `generalsms`
--
ALTER TABLE `generalsms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `groupfees`
--
ALTER TABLE `groupfees`
  ADD PRIMARY KEY (`groupfeeid`);

--
-- Indexes for table `holiday`
--
ALTER TABLE `holiday`
  ADD PRIMARY KEY (`holidayid`);

--
-- Indexes for table `payfees`
--
ALTER TABLE `payfees`
  ADD PRIMARY KEY (`payfeeid`);

--
-- Indexes for table `paymentremindersms`
--
ALTER TABLE `paymentremindersms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pendingfee`
--
ALTER TABLE `pendingfee`
  ADD PRIMARY KEY (`pendingfeeid`);

--
-- Indexes for table `school`
--
ALTER TABLE `school`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`staffid`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`studentid`);

--
-- Indexes for table `studentreport`
--
ALTER TABLE `studentreport`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `studentrollback`
--
ALTER TABLE `studentrollback`
  ADD PRIMARY KEY (`studentrollbackid`);

--
-- Indexes for table `studentrollbackreference`
--
ALTER TABLE `studentrollbackreference`
  ADD PRIMARY KEY (`referenceid`);

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`subjectid`);

--
-- Indexes for table `subjectgroup`
--
ALTER TABLE `subjectgroup`
  ADD PRIMARY KEY (`subjectgroupid`);

--
-- Indexes for table `trust`
--
ALTER TABLE `trust`
  ADD PRIMARY KEY (`trustid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `user_logs`
--
ALTER TABLE `user_logs`
  ADD PRIMARY KEY (`loginid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `amenityfee`
--
ALTER TABLE `amenityfee`
  MODIFY `amenityfeeid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `birthday_wish`
--
ALTER TABLE `birthday_wish`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=117;

--
-- AUTO_INCREMENT for table `coursefee`
--
ALTER TABLE `coursefee`
  MODIFY `coursefeeid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `extrafee`
--
ALTER TABLE `extrafee`
  MODIFY `extrafeeid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `feescollection`
--
ALTER TABLE `feescollection`
  MODIFY `feecollectid` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `feesmaster`
--
ALTER TABLE `feesmaster`
  MODIFY `feesid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `generalsms`
--
ALTER TABLE `generalsms`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `groupfees`
--
ALTER TABLE `groupfees`
  MODIFY `groupfeeid` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `holiday`
--
ALTER TABLE `holiday`
  MODIFY `holidayid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `payfees`
--
ALTER TABLE `payfees`
  MODIFY `payfeeid` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `paymentremindersms`
--
ALTER TABLE `paymentremindersms`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pendingfee`
--
ALTER TABLE `pendingfee`
  MODIFY `pendingfeeid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `school`
--
ALTER TABLE `school`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=125;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `staffid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `studentid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `studentreport`
--
ALTER TABLE `studentreport`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `studentrollback`
--
ALTER TABLE `studentrollback`
  MODIFY `studentrollbackid` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `studentrollbackreference`
--
ALTER TABLE `studentrollbackreference`
  MODIFY `referenceid` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `subject`
--
ALTER TABLE `subject`
  MODIFY `subjectid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `subjectgroup`
--
ALTER TABLE `subjectgroup`
  MODIFY `subjectgroupid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `trust`
--
ALTER TABLE `trust`
  MODIFY `trustid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user_logs`
--
ALTER TABLE `user_logs`
  MODIFY `loginid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
