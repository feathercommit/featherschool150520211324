<!-- Start Main project js, jQuery, Bootstrap -->
<script src="assets/bundles/lib.vendor.bundle.js"></script>

<!-- Start project main js  and page js -->
<script src="assets/js/core.js"></script>