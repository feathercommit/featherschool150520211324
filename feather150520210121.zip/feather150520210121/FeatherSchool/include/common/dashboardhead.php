<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="icon" href="favicon.ico" type="image/x-icon"/>
<title>:: Feather </title>



<!-- Bootstrap Core and vandor -->
<link rel="stylesheet" href="assets/plugins/bootstrap/css/bootstrap.min.css" />
<link rel="stylesheet" href="assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker3.min.css">
<link rel="stylesheet" href="assets/plugins/dropify/css/dropify.min.css">
<link rel="stylesheet" href="assets/plugins/summernote/dist/summernote.css"/>

<!-- Core css -->
<link rel="stylesheet" href="assets/css/style.min.css"/>



<link rel="stylesheet" type="text/css" href="assets/cssd/datatables.min.css" />
<!--<link rel="stylesheet" href="assets/cssd/bootstrap.min.css" />-->
 <style>
        .dataTables_length {
            margin-bottom: 30px;
        }
        
        .dataTables_length select {
            border: 1px solid #e4e4e4;
        }
        
        .dt-buttons a {
            margin-left: 12px;
            font-size: 12px;
            padding: 6px;
            border: 1px solid #e4e4e4;
            background: #FFF;
            box-shadow: 0px 0px 14px 0px #ececec;
        }
        
        .dataTables_filter input {
            border: 1px solid #e4e4e4;
        }
        
        .table-striped tbody tr {
            line-height: 30px;
        }
 </style>	




      <!-- Include SmartWizard CSS -->
      <link href="dist/css/smart_wizard.css" rel="stylesheet" type="text/css" />

<!-- Optional SmartWizard theme-->
<link href="dist/css/smart_wizard_theme_circles.css" rel="stylesheet" type="text/css" />
<link href="dist/css/smart_wizard_theme_arrows.css" rel="stylesheet" type="text/css" />
<link href="dist/css/smart_wizard_theme_dots.css" rel="stylesheet" type="text/css" /> 

</head>