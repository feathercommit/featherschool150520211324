
    <!-- Start Quick menu with more functio -->
    <div class="user_div">
        <ul class="nav nav-tabs">
            <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#righttab-statistics">Help Document</a></li>           
        </ul>
        <div class="tab-content mt-3">
            <div class="tab-pane fade show active" id="righttab-statistics" role="tabpanel">
                 <div class="card">
                    <div class="card-body top_counter">               
                        <div class="content">  
                                                                 
                        </div>
                    </div>
                </div>
               
            </div>
            
       

        </div>
    </div>