<?php    
$URLPATH="http://localhost/FeatherSchool/"; 
$HOSTPATH = $URLPATH;
$ROOTPATH = "http://localhost/";

 if(!defined('iEditValid'))
{ ?>
<script>location.href='index.php';</script> 
<?php }   ?> 