   
 <input onclick="bcFunction()" type="checkbox" id="bc" name="bc" aria-label="Checkbox for following text input" class="ml-4"><label id="newnew" class="ml-1">BC</label>
 <input onclick="bcFunction()" type="checkbox" id="mbc" name="mbc" aria-label="Checkbox for following text input" class="ml-4"><label id="newnew" class="ml-1">MBC</label>
 <input onclick="bcFunction()" type="checkbox" id="sc" name="sc" aria-label="Checkbox for following text input" class="ml-4"><label id="newnew" class="ml-1">SC</label>
 <input onclick="bcFunction()" type="checkbox" id="st" name="st" aria-label="Checkbox for following text input" class="ml-4"><label id="newnew" class="ml-1">ST</label>
 <input onclick="bcFunction()" type="checkbox" id="obc" name="obc" aria-label="Checkbox for following text input" class="ml-4"><label id="newnew" class="ml-1">OBC</label>
 <input onclick="bcFunction()" type="checkbox" id="dnc" name="dnc" aria-label="Checkbox for following text input" class="ml-4"><label id="newnew" class="ml-1">DNC</label>
 <input onclick="bcFunction()" type="checkbox" id="others" name="others" aria-label="Checkbox for following text input" class="ml-4"><label id="newnew" class="ml-1">Others</label>


<div id="confirmContent">

</div>

