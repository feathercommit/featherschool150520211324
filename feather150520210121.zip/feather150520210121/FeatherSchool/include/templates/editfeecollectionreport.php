<div class="ml-4 mt-4">

    <div class="row clearfix">
                            <div class="col-sm-4">
                                    <div class="card-header">
                                      <h3 class="card-title"><div class="text-light bg-azure" data-class="bg-warning">FEE COLLECTION REPORT</div></h3>  
                                </div>
                            </div>
                        </div>


<div class="card-body row">
<div class="col-sm-4">
<span>Select The Academic Year</span>
         <select tabindex="1" id="academicyear"  name="academicyear"  class="form-control" onchange="collectionreport()">
                                               <option value="">--Select Year--</option>
                                               <option value="2001-2002">2001-2002</option>
                                               <option value="2002-2003">2002-2003</option>
                                               <option value="2003-2004">2003-2004</option>
                                               <option value="2004-2005">2004-2005</option>
                                               <option value="2005-2006">2005-2006</option>
                                               <option value="2006-2007">2006-2007</option>
                                               <option value="2007-2008">2007-2008</option>
                                               <option value="2008-2009">2008-2009</option>
                                               <option value="2009-2010">2009-2010</option>
                                               <option value="2010-2011">2010-2011</option>
                                               <option value="2011-2012">2011-2012</option>
                                               <option value="2012-2013">2012-2013</option>
                                               <option value="2013-2014">2013-2014</option>
                                               <option value="2014-2015">2014-2015</option>
                                               <option value="2015-2016">2015-2016</option>
                                               <option value="2016-2017">2016-2017</option>
                                               <option value="2017-2018">2017-2018</option>
                                               <option value="2018-2019">2018-2019</option>
                                               <option value="2019-2020">2019-2020</option>
                                               <option value="2020-2021">2020-2021</option>
                                               <option value="2021-2022">2021-2022</option>
                                            </select>
</div>
</div>

<div id="feecollectioncontent">
</div>
   
</div>
