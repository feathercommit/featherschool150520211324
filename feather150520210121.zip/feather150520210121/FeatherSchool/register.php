<!doctype html>
<html lang="en" dir="ltr">
<?php include "include/common/accounthead.php"?>
<body class="font-muli theme-cyan gradient">

<div class="auth option2">
    <div class="auth_left">
        <div class="card">
            <div class="card-body">
                <div class="text-center">
                    <a class="header-brand" href=""><i class="fa fa-graduation-cap brand-logo"></i></a>
                    <div class="card-title">Create new account</div>
                    <button type="button" class="btn btn-facebook"><i class="fa fa-facebook mr-2"></i>Facebook</button>
                    <button type="button" class="btn btn-google"><i class="fa fa-google mr-2"></i>Google</button>
                    <h6 class="mt-3 mb-3">Or</h6>
                </div>
                <div class="form-group">
                    <label class="form-label">Name</label>
                    <input type="text" class="form-control" placeholder="Enter name">
                </div>
                <div class="form-group">
                    <label class="form-label">Email address</label>
                    <input type="email" class="form-control" placeholder="Enter email">
                </div>
                <div class="form-group">
                    <label class="form-label">Password</label>
                    <input type="password" class="form-control" placeholder="Password">
                </div>
                <div class="form-group">
                    <label class="custom-control custom-checkbox">
                    <input type="checkbox" class="custom-control-input" />
                    <span class="custom-control-label">Agree the <a href="#">terms and policy</a></span>
                    </label>
                </div>
                <div class="text-center">
                    <button type="submit" class="btn btn-primary btn-block">Create new account</button>
                    <div class="text-muted mt-4">Already have account? <a href="index.php">Sign in</a></div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include "include/common/accountfooter.php"?>
</body>
</html>